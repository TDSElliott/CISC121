"""
Main function for use in the first part of Assignment 3.  

STUDENTS MUST HAND IN A MODIFIED VERSION OF THIS MODULE AS SPECIFIED
IN THE INSTRUCTIONS FOR ASSIGNMENT 3.

This part of Assignment 3 was created by Margaret Lamb and is licensed
under Creative Commons Attribution-NonCommercial (CC BY-NC). 
"""
   
########################################################################
## Put Your Function Calls Here
########################################################################
from Assignment3Part1 import printTimingTable

def main() :
    print("Please add your function calls here.")
    printTimingTable('mystery1', 10, 1000)

    printTimingTable('mystery2', 10, 10000)

    printTimingTable('mystery3', 10, 500)

    printTimingTable('mystery4', 10, 10000)
main()


